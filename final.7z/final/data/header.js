export const header_data = [
  { name: "Home", link: "/" },
  { name: "FAQ", link: "/faq" },
  { name: "Contact Us", link: "/contact" },
];
