export const criteria = [
  { label: "BI", value: "BI" },
  { label: "BF", value: "BF" },
  { label: "Blex", value: "Blex" },
  { label: "Bll", value: "BII" },
  { label: "HP", value: "HP" },
  { label: "AP", value: "AP" },
  { label: "AU", value: "AU" },
  { label: "SA", value: "SA" },
  { label: "öS", value: "öS" },
];
