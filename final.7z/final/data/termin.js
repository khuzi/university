export const termins = [
  { label: "Urval1", value: "urval1" },
  { label: "Urval2", value: "urval2" },
];
