import React from "react";

import { MetaInfo } from "../components";

export default function Faq() {
  return (
    <div>
      <MetaInfo title="faq" />
      <h1>FAQ Page</h1>
    </div>
  );
}
